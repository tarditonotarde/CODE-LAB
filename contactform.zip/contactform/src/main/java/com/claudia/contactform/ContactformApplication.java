package com.claudia.contactform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactformApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactformApplication.class, args);
	}

}
